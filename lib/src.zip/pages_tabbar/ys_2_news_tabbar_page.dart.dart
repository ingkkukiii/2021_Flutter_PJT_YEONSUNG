import 'package:flutter/material.dart';

class YSungNewsTabBarPage extends StatelessWidget {
  const YSungNewsTabBarPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
    );
  }
}
