import 'package:flutter/material.dart';

class YSungClubTabBarPage extends StatelessWidget {
  const YSungClubTabBarPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,
    );
  }
}
