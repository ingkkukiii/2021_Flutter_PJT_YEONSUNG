import 'package:flutter/material.dart';

class YSungConvenienceTabBarPage extends StatelessWidget {
  const YSungConvenienceTabBarPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.orangeAccent,
    );
  }
}
