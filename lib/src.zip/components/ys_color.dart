import 'package:flutter/material.dart';

Color YSungColor = Color.fromARGB(255, 80, 176, 209);
Color YSungColor2 = Color(0xffEF238E);
Color YSungColor3 = Color(0xffB5DC10);