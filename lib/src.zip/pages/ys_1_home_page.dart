import 'package:flutter/material.dart';

class YSungHomePage extends StatelessWidget {
  const YSungHomePage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,
    );
  }
}
