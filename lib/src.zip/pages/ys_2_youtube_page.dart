import 'package:flutter/material.dart';

class YSungYoutubePage extends StatelessWidget {
  const YSungYoutubePage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
    );
  }
}
