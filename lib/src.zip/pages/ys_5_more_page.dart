import 'package:flutter/material.dart';

class YSungMorePage extends StatelessWidget {
  const YSungMorePage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.pinkAccent,
    );
  }
}
